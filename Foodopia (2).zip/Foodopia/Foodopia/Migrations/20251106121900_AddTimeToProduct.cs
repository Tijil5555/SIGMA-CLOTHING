﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Foodopia.Migrations
{
    /// <inheritdoc />
    public partial class AddTimeToProduct : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Time",
                table: "Products",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Time",
                table: "Products");
        }
    }
}

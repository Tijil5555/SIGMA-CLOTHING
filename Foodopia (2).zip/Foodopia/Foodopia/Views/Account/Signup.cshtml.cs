using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Foodopia.Views.Account
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
